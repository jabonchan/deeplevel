<div align="center">
    <img src="./assets/logo.png" alt="Logo" width="250">
    <h3><i>Complex data types made easy 🗃️</i></h3><br />
    <img src="https://github.com/jabonchan/deeplevel/actions/workflows/deno.yml/badge.svg?branch=main"></img>
    <img src="https://img.shields.io/badge/Tested%20on%20Deno-2.7.14-blue"></img>
    <img src="https://img.shields.io/badge/Dependencies-0-yellow"></img>
    <hr /><br />
</div>

A 0 dependencies 🥳 low-level, **ABI-accurate** struct/union/array layout and serialization library for TypeScript, Deno 🦖.

<hr /><br />

## Why? 🤔

Since Deno introduced **FFI** support, I immediately fell in love with its API. However, it was missing something essential: support for complex data types. There was no built-in way to define or work with structures, unions, arrays, and similar constructs-features that are fundamental when dealing with **FFI**.

Out of that need, I created **DeepLevel**: a library designed to provide a clean and intuitive API while remaining robust enough to handle low-level memory layouts and data structures with precision.

## Coding Style ✍️

<img align="right" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Deno_Logo_2024.svg/250px-Deno_Logo_2024.svg.png" alt="Deno Logo" width="80" height="80" />

The **DeepLevel** project follows Deno's official formatting standards. All source code is automatically formatted using the `deno fmt` command, with settings defined in the `deno.json` configuration file.


<hr /><br />

**DeepLevel** lets you define C/C++-like data structures in TypeScript with **exact memory layout control**, including:

- Structs
- Unions
- Arrays

It follows the ABI behavior of **MSVC, GCC, and Clang (x64)** for standard-layout types.


<hr /><br />

## ✨ Features

- 🧠 **ABI-accurate layout**
  - Correct alignment, padding, and offsets
  - Matches MSVC / GCC / Clang (x64)

- 📦 **Binary serialization**
  - Pack JS objects into raw memory buffers
  - Unpack buffers back into structured objects

- 🔁 **Union support**
  - Proper memory overlap

- 📏 **Packed structs**
  - Disable padding (`#pragma pack(1)` equivalent)

- 🧬 **Nested structures and unions**
  - Structs inside structs
  - Unions inside structs
  - Arrays inside structs
  - Arbitrary deep nesting

- 📚 **Arrays**
  - Fixed-length arrays with correct stride

- 🧩 **Shape-preserving type system**
  - Types directly mirror the structure of defined layouts. Structs, unions, and arrays are represented as nested TypeScript object shapes, providing accurate typing that reflects the underlying memory layout.

- 📋 **Constants**
  - Provides exhaustive constants for Unix systems, Windows systems, and dinamically generated constants that match the target platform's properties.
  - Exhaustive list of C/C++/Windows data types mapped to Deno FFI types.

- 💻 **Target system integration**
  - There are system constants that match the target system's properties, like its architecture, endianness and more.
  - Cross-platform

- 👨‍💻 **Easy debugging**
  - Using ``Deno.inspect()`` or ``console.log()`` you can get a nice view of the complex data type, including offset of each field, size, alignment, endianness and more. 
---

## Importing 📥

You can import **DeepLevel** in your projects like this:

```ts
import * as deeplevel from "jsr:@jabonchan/deeplevel";
```

## Quick Examples and Showcases 🚀

**Code:**
> Creating an structure is more easy than ever!
```ts
import * as deeplevel from "./mod.ts";

const t = deeplevel.constants.DefaultPrimitiveTypes;

const Vec3 = new deeplevel.Struct({
    fields: [
        { name: "x", type: t["float"] },
        { name: "y", type: t["float"] },
        { name: "z", type: t["float"] },
    ]
});

const value = { x: 1, y: 2, z: 3 };

const buffer = Vec3.pack(value);
const result = Vec3.unpack(buffer);

console.log(result);
```
**Output:**
> Result is a normal JS object.
```ts
{ x: 1, y: 2, z: 3 }
```

**Code:**
> Creating an union.
```ts
import * as deeplevel from "./mod.ts";

const t = deeplevel.constants.DefaultPrimitiveTypes;

const U = new deeplevel.Union({
    a: t["int"],
    b: t["double"]
});

console.log(U);
```
**Output:**
> Isn't it beautiful how complex data is printed to the console?
```cpp
(Offset:0x00:0 Size:0x08:8) union unnamed {
    Endianness: Little // (Or "Big" depending on your system)
    Alignment: 0x08:8 Natural
    Padding: 0x00:0
    Total Size: 0x08:8
    Size: 0x08:8

    (Offset:0x00:0 Size:0x04:4) i32 a
    (Offset:0x00:0 Size:0x08:8) f64 b
}
```

## Documentation 📚

### Class ``deeplevel.Struct``


## Running Tests ⚙️

**DeepLevel** uses Deno's built-in test feature. To run all the tests, use the following command _(Some permissions may be required like ``--allow-ffi``)_:
```bash
deno test
```

## Dependencies 🗃️

**DeepLevel** is dependency free! 🥳

## LICENSE 🔒

**DeepLevel** is licensed under the MIT License. By using this library, you agree to all the terms and conditions stated in the license.